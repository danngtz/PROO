//KEVIN DANIEL GUTIERREZ MENCHACA
#include <iostream>

int main() {
    int arreglo[] = {1, 2, 3, 4, 5};
    int* ptrArreglo = arreglo; // El nombre del array es la direcci�n del primer elemento

    std::cout << "Tercer elemento: " << *(ptrArreglo + 2) << std::endl;

    // Tambi�n se puede iterar con punteros.
    std::cout << "Elemento siguiente: " << *(ptrArreglo + 1) << std::endl;

    return 0;
}

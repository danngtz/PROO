//KEVIN DANIEL GUTIERREZ MENCHACA
#include <iostream>

int main() {
    int* ptr = nullptr; // Inicializaci�n con un puntero nulo

    if (ptr == nullptr) {
        std::cout << "El puntero es nulo." << std::endl;
    } else {
        std::cout << "El valor apuntado por el puntero es: " << *ptr << std::endl;
    }

    return 0;
}

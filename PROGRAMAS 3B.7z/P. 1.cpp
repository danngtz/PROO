//KEVIN DANIEL GUTIERRE MENCHACA
#include <iostream>

void incrementar(int* valor) {
    (*valor)++; // Incrementa el valor al que apunta 'valor'
}

int main() {
    int num = 10;

    std::cout << "Valor antes de incrementar: " << num << std::endl;

    incrementar(&num); // Pasa la direcci�n de 'num' a la funci�n

    std::cout << "Valor despu�s de incrementar: " << num << std::endl;

    return 0;
}
